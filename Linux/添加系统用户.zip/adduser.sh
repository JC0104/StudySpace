#! /bin/bash
#
#batch ass user with file called users.list
#
chattr -i /etc/passwd
chattr -i /etc/group
chattr -i /etc/gshadow
chattr -i /etc/shadow
for username in $(more users.list)
do 
if [ -n $username ]
then
	useradd -m $username
	echo
	echo $username"12#$" | passwd --stdin $username
	echo
	echo "User $username's passwd is changed!"
else
	echo "The username is null!"
fi
done
chattr +i /etc/passwd
chattr +i /etc/group
chattr +i /etc/gshadow
chattr +i /etc/shadow
chmod +x /etc