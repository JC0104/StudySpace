#! /bin/bash
#
#batch ass user with file called users.list
#
chattr -i /etc/passwd
chattr -i /etc/group
chattr -i /etc/gshadow
chattr -i /etc/shadow

echo "Unicom12#$" | passwd --stdin root

chattr +i /etc/passwd
chattr +i /etc/group
chattr +i /etc/gshadow
chattr +i /etc/shadow
chmod +x /etc